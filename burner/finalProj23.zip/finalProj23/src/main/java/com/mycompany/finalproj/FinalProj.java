/***************************************
 * Project: 
 * Programmer: Aris Ariawan
 * Date: Month #, 2023
 * Program: ----.java
 ***************************************/
package com.mycompany.finalproj;

import com.laserfiche.repository.api.clients.impl.model.Entry;
import com.mycompany.sampleproject.Sample;

/**
 *
 * @author arisariawan
 */
public class FinalProj {

    public static void main(String[] args) {
        
        
       Sample file1 = new Sample(16);
       Sample file2 = new Sample(17);
       
      file1.createFile();
      file2.createFile();
        
        
        
    }
}
